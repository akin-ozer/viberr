---
format: viberr-board/1
name: Release desk
taskPrefix: REL
stages:
  - { id: intake, name: Intake, color: slate }
  - { id: draft, name: Draft, color: violet }
  - { id: review, name: Review, color: amber }
  - { id: shipped, name: Shipped, color: green }
workflow:
  - { from: intake, to: draft, boundary: auto }
  - { from: draft, to: review, boundary: approval }
  - { from: review, to: shipped, boundary: human }
agents:
  - profileId: operator
  - profileId: release-manager
    capabilities:
      - { capabilityId: report-validation-verdict, mode: direct }
requiredReviewers:
  - { stageId: review, profileId: release-manager }
rulingsKb: release-rulings
knowledgeBases:
  - dir: release-rulings
    name: Release rulings
skills:
  - name: release-notes
    summary: Drafts release notes from merged pull requests.
---

Release notes, from intake to shipped. Written by hand, zipped by Finder.
