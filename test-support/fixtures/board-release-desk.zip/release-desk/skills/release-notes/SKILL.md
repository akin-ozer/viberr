---
name: release-notes
description: Drafts release notes from merged pull requests.
---

# Release notes

Group the merged pull requests by area. One line each, in the user's words.
